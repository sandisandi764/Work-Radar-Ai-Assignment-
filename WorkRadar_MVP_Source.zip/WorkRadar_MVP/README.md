# WorkRadar MVP

A responsive, single-page prototype for a manager-facing team intelligence dashboard.

## Run locally
Open `index.html` in a modern browser. No build step, package manager, API key, or backend is required.

## Included screens
- Dashboard with daily overview, AI-assisted summary, priorities, activity, team pulse
- Priority feed with filters
- Search across mock work items
- Item details with owner, due date, status, blocker, next step, and activity timeline
- Empty and error state examples

## Interactive actions
- Assign: choose a teammate and update the displayed owner
- Mark Done: update the work item's status
- Snooze: move an item out of the active queue for a selected period
- Search and priority filters update the visible results

## Data and AI transparency
This MVP uses seeded mock data. The “AI-assisted” summary is a deterministic, rule-based synthesis of the demo state, not a live LLM call. The UI labels this as demo-generated to avoid implying a backend AI integration. Actions persist only in the current browser session and do not write to external tools.

## AI use and manual modifications
AI assistance was used to draft the interface structure, CSS design system, mock content, and interaction logic. The implementation was manually assembled into a self-contained HTML file; copy, information hierarchy, states, action flows, responsive behavior, and the mock-data caveats were explicitly reviewed and refined. Final AI Workflow documentation should be updated to reflect the actual tools and edits used during the full project.

## Limitations / future work
- No live Slack, Jira, GitHub, or email integrations
- No authentication, persistent database, or team permissions
- Replace rule-based summary with a grounded LLM workflow and source citations before production
- Add automated tests, accessibility audit, and integration health monitoring
